import java.rmi.RemoteException;

import ade.ADEServer;
import com.action.ActionServer;

public interface Arch extends ActionServer {
}
