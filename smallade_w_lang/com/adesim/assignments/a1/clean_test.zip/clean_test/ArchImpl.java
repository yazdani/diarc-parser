// A sample architecture file.
//    compile with javac -cp toy1.jar ArchImpl.java Arch.java
//    run with java -jar toy1.jar ArchImpl


import com.action.ActionServerImpl;

import java.rmi.*;
import java.util.HashMap;

public class ArchImpl extends ActionServerImpl implements Arch {
	
	private static final long serialVersionUID = 1L;
	
	private boolean readyToRunArchitecture = false;

	/** 
	 * <code>runArchitecture</code> is called periodically to perform
	 * whatever sensing and acting required by the architecture.
	 */
	boolean verbose = false;
	
	public void runArchitecture()
	{
		if (!readyToRunArchitecture) {
			return;
		}
		
		boolean[] obsts = checkObstacles();
		
		if (verbose)
			System.out.println ("Sensor readings:  right = " + obsts[0] + 
							", front = " + obsts[1] + 
							", left = " + obsts[2]);

		
		// My initial idea with the navigation was fairly simple:  
		//   if the robot saw that it is clear on the front and there's a wall 
		//   on the right, the robot should would straight; otherwise, it would
		//   turn left.  The problem with this scheme was that up until
		//   the robot was close enough to something, it saw nothing.  
		//   More troubling still was the robot's tendency -- upon turning 
		//   some 30-40 degrees, to STOP seeing that there is an obstacle on
		//   the front, yet to bump into it if it were told to go straight.
		

		// So really, the only TRUE check that the robot can forge ahead
		//    is to see whether ALL sensors show no obstacle.  
		if (! (obsts[0] || obsts[1] || obsts[2]))
		{
			goStraight();
			if (verbose) System.out.println("...... all clear, go straight!");
		}
		
		// if all is NOT clear:
		else
		{
			if (obsts[0]) // if obstacle on the right, turn left
						  //    this is the default action even if
						  //    both the left and the right have obstacles
			{
				if (verbose) System.out.println("...... ostacle on the right, turning left");
				turnLeft();
			}
			else // else, must be on the left
			{
				if (verbose) System.out.println("...... ostacle on the left, turning right");
				turnRight();
			}
		}
		
		
	}

	/** 
	 * Constructs the ActionServerArch.
	 */
	public ArchImpl() throws RemoteException {
		super();
		
		new Thread() {
			public void run() {
				
				// wait until local services are ready, and until gets default velocities below 
				//    (At which point, will set the readyTorunArchitecture flag).
				while (!localServicesReady() || (!readyToRunArchitecture)) {
					try {
						sleep(100);
					} catch (InterruptedException e) {
						// can't sleep, busy-wait
					}
					
					try {
						double[] defVels = (double[]) callMethod("getDefaultVels");
						defTV = defVels[0];
						defRV = defVels[1];
						readyToRunArchitecture = true;
					} catch (Exception e) {
						// do nothing, just wait
					}
				}
				
				System.out.println("Default velocities obtained, SampleActionServer starting to run!");
				
			};
		}.start();		
	}
}
